"""Setup such that environment can be created using gym.make()."""
from motion_imitation.envs.gym_envs.a1_gym_env import A1GymEnv
