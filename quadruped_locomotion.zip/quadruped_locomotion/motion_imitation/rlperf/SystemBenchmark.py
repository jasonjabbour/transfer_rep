import os
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
os.sys.path.insert(0, parentdir)

import numpy as np 
import pandas as pd
import time
import matplotlib.pyplot as plt
import tracemalloc
from pyJoules.energy_meter import measure_energy, EnergyContext
from pyJoules.handler.pandas_handler import PandasHandler
from mpi4py import MPI

from run_utils import RunUtils as RunUtils

TIMESTEPS_PER_ACTORBATCH = 4096
OPTIM_BATCHSIZE = 256
# Number of timesteps used to evaluate a metric (not including clipped timesteps)
LATENCY_NUM_STEPS = MEMORY_NUM_STEPS = ENERGY_NUM_STEPS = 5000
THROUGHPUT_NUM_STEPS = 1000
THROUGHPUT_SAMPLES = 10
STEPS_PER_EPISODE = 500
# Number of timesteps to start measurements
TIMESTEP_CLIP = 500

# Commerial Electricity Rate in Boston
# https://www.electricitylocal.com/states/massachusetts/boston/
kWh_cents = 13.84

MODEL_FILES_DIR = 'motion_imitation/data/policies/'
MOTION_FILES_DIR = 'motion_imitation/data/motions/'
GAITS = ['dog_pace', 'dog_trot', 'dog_spin']

class SystemBenchmark(object):
    '''Benchmarking Class for RL-Perf'''

    def __init__(self, 
                args,
                latency=False, 
                throughput=False,
                memory=False, 
                energy_cost=False, 
                power_consumption=False, 
                wallclock_training_time=False, 
                carbon_emissions=False) -> None:
        '''Constructs the Systems Metrics forRL-Perf 
        
        Args:
            model:
            env:
            latency: *Update*
            throughput: *Update*
            memory: *Update*
            energy_cost: *Update*
            power_consumption: *Update*
            wallclock_training_time: *Update*
            carbon_emissions: *Update*
        '''

        # Latency
        self._latency = []
        self._avg_latency = []
        # Memory
        self._peak_allocated_memory = []
        self._avg_peak_allocated_memory = []
        # Throughput
        self._avg_throughput = []

        # Energy 
        self._energy = []
        self._avg_energy = []

        # Inference ----------------

        # Measure Latency 
        if latency:
            self.benchmark_system_metric(args, 'latency')
            self.plot_latency()

        # Measure Throughput
        if throughput:
            self.benchmark_system_metric(args, 'throughput')
            self.plot_throughput()

        # Measure Memory
        if memory:
            self.benchmark_system_metric(args, 'memory')
            self.plot_memory()

        # Measure Energy Cost
        if energy_cost:
            self.benchmark_system_metric(args, 'energy')


        # Training -----------------

        # Measure Power Consumption
        # TODO

        # Measure Wall-Clock Training Time
        # TODO

        # Measure Carbon Emmission 
        # TODO

    def benchmark_system_metric(self, args, metric):
        '''Calculate Latency Across Different Models and Motions'''
        
        for gait in GAITS: 
            # Construct motion file
            motion_file = MOTION_FILES_DIR + gait + '.txt'
            # Construct model file
            model_file = MODEL_FILES_DIR + gait + '.zip'
            
            # Create a run utils instance
            run = RunUtils(seed=args.seed, 
                    benchmark=args.benchmark, 
                    mode=args.mode, 
                    motion_file=motion_file, 
                    visualize=args.visualize, 
                    output_dir=args.output_dir, 
                    num_test_episodes=args.num_test_episodes, 
                    model_file=model_file, 
                    total_timesteps=args.total_timesteps, 
                    int_save_freq=args.int_save_freq)

            # Built environment
            env = run.build_environment()

            # Build Model
            model = run.build_model(env, TIMESTEPS_PER_ACTORBATCH, OPTIM_BATCHSIZE)

            # Decide which metric to evaluate
            if metric == 'latency':
                avg_latency, latency_lst = self.calculate_latency(model, env)
                print(f'Average Latency for {gait} Gait over {LATENCY_NUM_STEPS} steps is {avg_latency} seconds')
                # Save latency of timesteps for this gait
                self._latency.extend(latency_lst)
                # Save average latency for this gate
                self._avg_latency.append(avg_latency)
            elif metric == 'throughput':
                # Get multiple samples for throughput
                for samp in range(THROUGHPUT_SAMPLES):
                    avg_throughput = self.calculate_throughput(model, env)
                    print(f'Throughput for {gait} Gait is {avg_throughput} examples/second')
                    # Save average throughput of all episodes
                    self._avg_throughput.append(avg_throughput)
            elif metric == 'memory':
                avg_peak_allocated_memory, peak_allocated_memory_lst = self.calculate_memory_policy_env(model, env)
                print(f'Average Peak Allocated Memory for {gait} Gait over {MEMORY_NUM_STEPS} steps is {avg_peak_allocated_memory} megabytes')
                # Save peak memory allocated in each episode for this gate
                self._peak_allocated_memory.extend(peak_allocated_memory_lst)
                # Save average peak allocated memory across all episodes for this gate
                self._avg_peak_allocated_memory.append(avg_peak_allocated_memory)
            elif metric == 'energy':
                energy_pandas_handler = PandasHandler()
                with EnergyContext(handler=energy_pandas_handler) as ctx:
                    self.calculate_energy(model, env)
                energy_df = energy_pandas_handler.get_dataframe()

                # Measurements come in microJoules. Convert to Joules
                CPU_energy_joules = energy_df['package_0'][0] / 1000000
                RAM_energy_joules = energy_df['core_0'][0] / 1000000
                GPU_energy_joules = energy_df['nvidia_gpu_0'][0] / 1000000

                CPU_energy_cost = (CPU_energy_joules/3600000)*(kWh_cents/100)
                RAM_energy_cost = (RAM_energy_joules/3600000)*(kWh_cents/100)
                GPU_energy_cost = (GPU_energy_joules/3600000)*(kWh_cents/100)
                Total_energy_cost = CPU_energy_cost + RAM_energy_cost + GPU_energy_cost

                print(f'The Total Energy (Joules) used for {gait} over {ENERGY_NUM_STEPS} steps is \
                \n CPU: {CPU_energy_joules} Cost @ {kWh_cents} Cents/kWh: {CPU_energy_cost} \
                \n RAM: {RAM_energy_joules} Cost @ {kWh_cents} Cents/kWh: {RAM_energy_cost} \
                \n GPU: {GPU_energy_joules} Cost @ {kWh_cents} Cents/kWh: {GPU_energy_cost} \
                \n Total Cost: {Total_energy_cost}')


            # Disconnect from pybullet client to enable next conneciton
            env.pybullet_client.disconnect()


    def calculate_latency(self, model, env):
        '''Measure the Latency of a given model
        
            return: 
                - average latency across all episodes
                - latency across every timestep in episodes
        '''

        steps_count = 0
        latency_lst = []
        o = env.reset()
        while steps_count < (LATENCY_NUM_STEPS + TIMESTEP_CLIP):
            start = time.perf_counter()
            a, _ = model.predict(o, deterministic=True)
            latency = time.perf_counter() - start
            o, r, done, info = env.step(a)
            latency_lst.append(latency)

            if (steps_count % STEPS_PER_EPISODE == 0):
                o = env.reset()
            
            steps_count+=1

        # Clip initial time steps when latency variance is high
        latency_lst = latency_lst[TIMESTEP_CLIP:]
        # Find average latency for this gait
        avg_latency = sum(latency_lst)/len(latency_lst)
            
        return avg_latency, latency_lst

    def plot_latency(self):
        
        # ---------------
        # Line Plot -----
        # ---------------

        # Make x indices
        x = list(range(0, len(self._latency)//len(GAITS)))
        
        start_step = 0
        stop_step = LATENCY_NUM_STEPS
        f1 = plt.figure()
        # Find each gait in the list and plot separately
        for gait in GAITS:
            plt.plot(x, self._latency[start_step:stop_step], label=gait)
            start_step+=LATENCY_NUM_STEPS
            stop_step+=LATENCY_NUM_STEPS

        # Label and Save Plot
        plt.title("Latency of Pace, Trot, and Spin Motions")
        plt.xlabel("Timestep")
        plt.ylabel('Latency (s)')
        plt.legend()
        plt.savefig("motion_imitation/rlperf/Captures/latency.png",
                    bbox_inches='tight', 
                    dpi=300)

        # ---------------
        # Bar Plot ------
        # ---------------
        start_step = 0
        stop_step = LATENCY_NUM_STEPS
        average_latency_lst = []
        std_latency_lst = []
        for gait in GAITS:
            # Get list of latency for this gait
            gait_latency = self._latency[start_step:stop_step]
            # Calculate mean latency
            average_latency_lst.append(np.mean(gait_latency))
            # Calculate Standard Deviation latency
            std_latency_lst.append(np.std(gait_latency))
            start_step+=LATENCY_NUM_STEPS
            stop_step+=LATENCY_NUM_STEPS

        x_pos = np.arange(len(average_latency_lst))
        f2 = plt.figure()
        plt.bar(x_pos, average_latency_lst,
                yerr=std_latency_lst,
                align='center', 
                alpha=0.5, 
                ecolor='black', 
                capsize=10)

        # Label and Save Plot
        plt.title("Average Latency of Pace, Trot, and Spin Motions")
        plt.xlabel("Gait")
        plt.ylabel('Average Latency (s)')
        plt.xticks(x_pos, GAITS)
        plt.savefig("motion_imitation/rlperf/Captures/average_latency.png",
                    bbox_inches='tight', 
                    dpi=300)
        
        print(f'The plotted avg latency and std is {average_latency_lst} and {std_latency_lst}')

    def calculate_throughput(self, model, env):
        '''Measure the Throughput of a given model
        
            returns: average throughput across all episodes
        '''

        steps_count = 0
        obs_lst = []
        
        # Collect observations
        o = env.reset()
        while steps_count < THROUGHPUT_NUM_STEPS:
            obs_lst.append(o)
            a, _ = model.predict(o, deterministic=True)
            o, r, done, info = env.step(a)

            if (steps_count % STEPS_PER_EPISODE == 0):
                o = env.reset()
            
            steps_count+=1
        
        # Pass all observations to model and time
        start_time = time.time()
        for obs in obs_lst:
            a, _ = model.predict(o, deterministic=True)
        end_time = time.time()

        # Calculate Throughput
        elapsed_time = end_time - start_time
        avg_throughput = len(obs_lst)/elapsed_time
        
        return avg_throughput
    
    def plot_throughput(self):
        
        # ---------------
        # Bar Plot ------
        # ---------------
        start_step = 0
        stop_step = THROUGHPUT_SAMPLES
        average_throughput_lst = []
        std_throughput_lst = []
        for gait in GAITS:
            # Get list of throughput samples for this gait
            gait_samp_throughput = self._avg_throughput[start_step:stop_step]
            # Calculate mean throughput of all samples
            average_throughput_lst.append(np.mean(gait_samp_throughput))
            # Calculate Standard Deviation throughput among samples
            std_throughput_lst.append(np.std(gait_samp_throughput))
            start_step+=THROUGHPUT_SAMPLES
            stop_step+=THROUGHPUT_SAMPLES

        x_pos = np.arange(len(average_throughput_lst))
        f2 = plt.figure()
        plt.bar(x_pos, average_throughput_lst,
                yerr=std_throughput_lst,
                align='center', 
                alpha=0.5, 
                ecolor='black', 
                capsize=10)

        # Label and Save Plot
        plt.title("Average Throughput of Pace, Trot, and Spin Motions")
        plt.xlabel("Gait")
        plt.ylabel('Average Throughput (examples/s)')
        plt.xticks(x_pos, GAITS)
        plt.savefig("motion_imitation/rlperf/Captures/average_throughput.png",
                    bbox_inches='tight', 
                    dpi=300)
        
        print(f'The plotted avg throughput and std is {average_throughput_lst} and {std_throughput_lst}')

    def calculate_memory_policy_env(self, model, env):
        '''Measure the Peak Allocated Memory of a given model
        
            returns:
                - average peak allocated memory across all episodes
                - peak allocated memory for each episode
        '''

        steps_count = 0
        peak_allocated_memory_lst = []
        
        o = env.reset()
        # Start memory collection
        tracemalloc.start()
        while steps_count < (LATENCY_NUM_STEPS + TIMESTEP_CLIP*4):
            a, _ = model.predict(o, deterministic=True)
            o, r, done, info = env.step(a)

            if (steps_count % STEPS_PER_EPISODE == 0):
                # Gather Allocated memory during episode
                current_memory, peak_memory = tracemalloc.get_traced_memory()
                # Stop memory collection
                tracemalloc.stop()
                # Convert to Megabytes from bytes
                peak_memory_mg = peak_memory /10**6

                # Save memory collection only after steady state
                if steps_count >= (TIMESTEP_CLIP*4):
                    peak_allocated_memory_lst.append(peak_memory_mg)

                # Reset Environment
                o = env.reset()

                # Start memory collection
                tracemalloc.start()
                
 
            steps_count+=1
        
        # Stop memory collection
        tracemalloc.stop()

        # get average allocated memory across all episodes
        avg_peak_allocated_memory = sum(peak_allocated_memory_lst)/len(peak_allocated_memory_lst)
    
        return avg_peak_allocated_memory, peak_allocated_memory_lst
    
    def plot_memory(self):

        # ---------------
        # Line Plot ------
        # ---------------
        x = list(range(1, 1 + len(self._peak_allocated_memory)//len(GAITS)))
        
        fig, ax = plt.subplots()

        start_step = 0
        stop_step = len(x)
        avg_episode_memory = []
        std_episode_memory = []
        for gait in GAITS:
            gait_memory = self._peak_allocated_memory[start_step:stop_step]
            avg_episode_memory.append(np.mean(gait_memory))
            std_episode_memory.append(np.std(gait_memory))
            ax.plot(x, gait_memory, label=gait)
            start_step+=len(x)
            stop_step+=len(x)

        ax.set_xticks(x)
        plt.title("Allocated Memory of Pace, Trot, and Spin Motions Per Episode")
        plt.xlabel("Episode")
        plt.ylabel('Allocated Memory (GB)')
        plt.legend()
        plt.savefig("motion_imitation/rlperf/Captures/allocated_memory.png", 
                    bbox_inches='tight', 
                    dpi=300)


        # ---------------
        # Bar Plot ------
        # ---------------
        x_pos = np.arange(len(avg_episode_memory))
        f2 = plt.figure()
        plt.bar(x_pos, avg_episode_memory,
                yerr=std_episode_memory,
                align='center', 
                alpha=0.5, 
                ecolor='black', 
                capsize=10)

        # Label and Save Plot
        plt.title("Average Peak Allocated Memory of Pace, Trot, and Spin Motions")
        plt.xlabel("Gait")
        plt.ylabel('Average Peak Allocated Memory (MB)')
        plt.xticks(x_pos, GAITS)
        plt.savefig("motion_imitation/rlperf/Captures/average_memory.png",
                    bbox_inches='tight', 
                    dpi=300)
        
        std_episode_memory = ["%.6f"%std for std in std_episode_memory]
        print(f'The plotted avg peak allocated memory and std is {avg_episode_memory} and {std_episode_memory}')
        
    @measure_energy
    def calculate_energy(self, model, env):
        '''Calculate energy consumption'''

        steps_count = 0
        o = env.reset()
        while steps_count < (LATENCY_NUM_STEPS + TIMESTEP_CLIP):
            a, _ = model.predict(o, deterministic=True)
            o, r, done, info = env.step(a)

            if (steps_count % STEPS_PER_EPISODE == 0):
                o = env.reset()
            
            steps_count+=1
    
    
        

